//
//  ViewController.swift
//  MVC Practice
//
//  Created by Vincent E. Hunter (Student) on 4/29/19.
//  Copyright © 2019 Vincent E. Hunter (Student). All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descLabel: UILabel!
    @IBOutlet weak var detailDescLabel: UILabel!
    
    let movie = Movie.init(title: incrediblesTitle,
                           description: incrediblesDescription,
                           detailedDescription: incrediblesDetailedDescription)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    @IBAction func updateButtonWasPressed(_ sender: Any) {
       titleLabel.text = movie.title
        descLabel.text = movie.description
        detailDescLabel.text = movie.detailedDescription
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

