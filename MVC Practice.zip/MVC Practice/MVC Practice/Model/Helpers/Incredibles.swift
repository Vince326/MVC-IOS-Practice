//
//  Incredibles.swift
//  MVC Practice
//
//  Created by Vincent E. Hunter (Student) on 4/29/19.
//  Copyright © 2019 Vincent E. Hunter (Student). All rights reserved.
//

import Foundation


let incrediblesTitle = "Incredibles 2"
let incrediblesDescription = "Everyone's favorite family of superheroes is back "
let incrediblesDetailedDescription = "Incredibles 2 is a 2019 American 3D computer-animated superhero film produced t Pizar Animation Studios and released by Walt Disney Pictures."
