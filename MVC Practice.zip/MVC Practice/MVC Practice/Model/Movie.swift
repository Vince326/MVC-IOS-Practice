//
//  Movie.swift
//  MVC Practice
//
//  Created by Vincent E. Hunter (Student) on 4/29/19.
//  Copyright © 2019 Vincent E. Hunter (Student). All rights reserved.
//

import Foundation


struct Movie {
    var title : String
    var description : String
    var detailedDescription : String
    
}





