//
//  CustomView.swift
//  MVC Practice
//
//  Created by Vincent E. Hunter (Student) on 4/29/19.
//  Copyright © 2019 Vincent E. Hunter (Student). All rights reserved.
//

import UIKit

class CustomView: UIView {

    override func awakeFromNib() {
        layer.borderColor = UIColor.black.cgColor
        layer.borderWidth = 5
        layer.cornerRadius = 15
        clipsToBounds = true
    }

}
